import React from 'react';
import { Link } from 'react-router-dom';
import { useBlog } from '../context/BlogContext';
import { 
  Plus, 
  FileText, 
  Eye, 
  Clock, 
  TrendingUp,
  Users,
  Heart,
  MessageCircle
} from 'lucide-react';
import { format } from 'date-fns';

export const Dashboard: React.FC = () => {
  const { posts } = useBlog();

  const publishedPosts = posts.filter(post => post.status === 'published');
  const draftPosts = posts.filter(post => post.status === 'draft');
  const recentPosts = posts.slice(0, 5);

  const stats = [
    { 
      label: 'Total Posts', 
      value: posts.length, 
      icon: FileText, 
      color: 'bg-blue-500',
      change: '+12%'
    },
    { 
      label: 'Published', 
      value: publishedPosts.length, 
      icon: Eye, 
      color: 'bg-green-500',
      change: '+8%'
    },
    { 
      label: 'Drafts', 
      value: draftPosts.length, 
      icon: Clock, 
      color: 'bg-yellow-500',
      change: '+3%'
    },
    { 
      label: 'Total Views', 
      value: '12.5K', 
      icon: TrendingUp, 
      color: 'bg-purple-500',
      change: '+23%'
    },
  ];

  return (
    <div className="p-6 lg:p-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-600 mt-1">Welcome back! Here's what's happening with your blog.</p>
        </div>
        <Link
          to="/editor"
          className="mt-4 sm:mt-0 inline-flex items-center px-6 py-3 bg-indigo-600 text-white font-medium rounded-xl hover:bg-indigo-700 transition-colors duration-200 shadow-sm"
        >
          <Plus className="w-5 h-5 mr-2" />
          New Post
        </Link>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat, index) => (
          <div key={index} className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-shadow duration-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">{stat.label}</p>
                <p className="text-3xl font-bold text-gray-900 mt-2">{stat.value}</p>
                <p className="text-sm text-green-600 mt-1 font-medium">{stat.change}</p>
              </div>
              <div className={`${stat.color} p-3 rounded-xl`}>
                <stat.icon className="w-6 h-6 text-white" />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Recent Posts */}
        <div className="lg:col-span-2 bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-gray-900">Recent Posts</h2>
            <Link to="/posts" className="text-indigo-600 hover:text-indigo-700 font-medium text-sm">
              View all
            </Link>
          </div>
          <div className="space-y-4">
            {recentPosts.map((post) => (
              <div key={post.id} className="flex items-center space-x-4 p-4 hover:bg-gray-50 rounded-xl transition-colors duration-200">
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-gray-900 truncate">{post.title}</h3>
                  <div className="flex items-center space-x-4 mt-1">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      post.status === 'published' 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-yellow-100 text-yellow-800'
                    }`}>
                      {post.status}
                    </span>
                    <span className="text-sm text-gray-500">{post.category}</span>
                    <span className="text-sm text-gray-500">{format(post.createdAt, 'MMM d')}</span>
                  </div>
                </div>
                <div className="flex items-center space-x-2 text-sm text-gray-500">
                  <Clock className="w-4 h-4" />
                  <span>{post.readingTime} min</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="space-y-6">
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Quick Actions</h2>
            <div className="space-y-3">
              <Link
                to="/editor"
                className="flex items-center p-3 text-left hover:bg-gray-50 rounded-xl transition-colors duration-200 w-full"
              >
                <Plus className="w-5 h-5 text-indigo-600 mr-3" />
                <span className="font-medium text-gray-900">Create New Post</span>
              </Link>
              <Link
                to="/posts?status=draft"
                className="flex items-center p-3 text-left hover:bg-gray-50 rounded-xl transition-colors duration-200 w-full"
              >
                <Clock className="w-5 h-5 text-yellow-600 mr-3" />
                <span className="font-medium text-gray-900">Review Drafts</span>
              </Link>
              <Link
                to="/categories"
                className="flex items-center p-3 text-left hover:bg-gray-50 rounded-xl transition-colors duration-200 w-full"
              >
                <FileText className="w-5 h-5 text-green-600 mr-3" />
                <span className="font-medium text-gray-900">Manage Categories</span>
              </Link>
            </div>
          </div>

          {/* Engagement Stats */}
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Engagement</h2>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <Users className="w-5 h-5 text-blue-500 mr-3" />
                  <span className="text-gray-900">Readers</span>
                </div>
                <span className="font-semibold text-gray-900">2.4K</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <Heart className="w-5 h-5 text-red-500 mr-3" />
                  <span className="text-gray-900">Likes</span>
                </div>
                <span className="font-semibold text-gray-900">891</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <MessageCircle className="w-5 h-5 text-green-500 mr-3" />
                  <span className="text-gray-900">Comments</span>
                </div>
                <span className="font-semibold text-gray-900">156</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};