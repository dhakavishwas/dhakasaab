import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useBlog } from '../context/BlogContext';
import { 
  Save, 
  Eye, 
  Send, 
  ArrowLeft, 
  Image, 
  Bold, 
  Italic, 
  List, 
  Link as LinkIcon,
  Hash,
  Quote,
  Code,
  Settings
} from 'lucide-react';
import { BlogPost } from '../types/blog';

export const PostEditor: React.FC = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const { posts, categories, createPost, updatePost, currentPost, setCurrentPost } = useBlog();
  
  const [formData, setFormData] = useState({
    title: '',
    content: '',
    excerpt: '',
    category: '',
    tags: [] as string[],
    status: 'draft' as 'draft' | 'published',
    author: 'Alex Johnson',
    seoTitle: '',
    seoDescription: ''
  });
  
  const [tagInput, setTagInput] = useState('');
  const [previewMode, setPreviewMode] = useState(false);
  const [showSEO, setShowSEO] = useState(false);

  useEffect(() => {
    if (id && id !== 'new') {
      const post = posts.find(p => p.id === id) || currentPost;
      if (post) {
        setFormData({
          title: post.title,
          content: post.content,
          excerpt: post.excerpt,
          category: post.category,
          tags: post.tags,
          status: post.status,
          author: post.author,
          seoTitle: post.seoTitle || '',
          seoDescription: post.seoDescription || ''
        });
      }
    }
  }, [id, posts, currentPost]);

  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const addTag = () => {
    if (tagInput.trim() && !formData.tags.includes(tagInput.trim())) {
      setFormData(prev => ({
        ...prev,
        tags: [...prev.tags, tagInput.trim()]
      }));
      setTagInput('');
    }
  };

  const removeTag = (tagToRemove: string) => {
    setFormData(prev => ({
      ...prev,
      tags: prev.tags.filter(tag => tag !== tagToRemove)
    }));
  };

  const handleSave = (status: 'draft' | 'published') => {
    const postData = {
      ...formData,
      status,
      excerpt: formData.excerpt || formData.content.substring(0, 150) + '...'
    };

    if (id && id !== 'new') {
      updatePost(id, postData);
    } else {
      createPost(postData);
    }

    navigate('/posts');
  };

  const insertFormatting = (before: string, after: string = '') => {
    const textarea = document.getElementById('content-editor') as HTMLTextAreaElement;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selectedText = formData.content.substring(start, end);
    const newText = before + selectedText + after;
    
    const newContent = formData.content.substring(0, start) + newText + formData.content.substring(end);
    setFormData(prev => ({ ...prev, content: newContent }));
    
    // Restore cursor position
    setTimeout(() => {
      textarea.focus();
      textarea.setSelectionRange(start + before.length, start + before.length + selectedText.length);
    }, 0);
  };

  const formatButtons = [
    { icon: Bold, action: () => insertFormatting('**', '**'), label: 'Bold' },
    { icon: Italic, action: () => insertFormatting('_', '_'), label: 'Italic' },
    { icon: Hash, action: () => insertFormatting('## '), label: 'Heading' },
    { icon: List, action: () => insertFormatting('- '), label: 'List' },
    { icon: Quote, action: () => insertFormatting('> '), label: 'Quote' },
    { icon: Code, action: () => insertFormatting('`', '`'), label: 'Code' },
    { icon: LinkIcon, action: () => insertFormatting('[', '](url)'), label: 'Link' },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <button
              onClick={() => navigate('/posts')}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors duration-200"
            >
              <ArrowLeft className="w-5 h-5 text-gray-600" />
            </button>
            <div>
              <h1 className="text-xl font-bold text-gray-900">
                {id && id !== 'new' ? 'Edit Post' : 'New Post'}
              </h1>
              <p className="text-sm text-gray-500">Create and publish your blog content</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-3">
            <button
              onClick={() => setPreviewMode(!previewMode)}
              className={`inline-flex items-center px-4 py-2 text-sm font-medium rounded-lg transition-colors duration-200 ${
                previewMode 
                  ? 'bg-indigo-100 text-indigo-700' 
                  : 'text-gray-700 hover:bg-gray-100'
              }`}
            >
              <Eye className="w-4 h-4 mr-2" />
              Preview
            </button>
            <button
              onClick={() => handleSave('draft')}
              className="inline-flex items-center px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors duration-200"
            >
              <Save className="w-4 h-4 mr-2" />
              Save Draft
            </button>
            <button
              onClick={() => handleSave('published')}
              className="inline-flex items-center px-4 py-2 text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg transition-colors duration-200"
            >
              <Send className="w-4 h-4 mr-2" />
              Publish
            </button>
          </div>
        </div>
      </div>

      <div className="flex">
        {/* Editor */}
        <div className="flex-1 p-6">
          <div className="max-w-4xl mx-auto">
            {!previewMode ? (
              <div className="space-y-6">
                {/* Title */}
                <div>
                  <input
                    type="text"
                    placeholder="Enter your post title..."
                    value={formData.title}
                    onChange={(e) => handleInputChange('title', e.target.value)}
                    className="w-full text-3xl font-bold border-none outline-none bg-transparent placeholder-gray-400 resize-none"
                  />
                </div>

                {/* Formatting Toolbar */}
                <div className="flex items-center space-x-2 py-4 border-y border-gray-200">
                  {formatButtons.map((button, index) => (
                    <button
                      key={index}
                      onClick={button.action}
                      title={button.label}
                      className="p-2 hover:bg-gray-100 rounded-lg transition-colors duration-200"
                    >
                      <button.icon className="w-5 h-5 text-gray-600" />
                    </button>
                  ))}
                  <div className="w-px h-6 bg-gray-300 mx-2" />
                  <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors duration-200">
                    <Image className="w-5 h-5 text-gray-600" />
                  </button>
                </div>

                {/* Content Editor */}
                <div>
                  <textarea
                    id="content-editor"
                    placeholder="Start writing your post..."
                    value={formData.content}
                    onChange={(e) => handleInputChange('content', e.target.value)}
                    className="w-full h-96 text-lg border-none outline-none bg-transparent placeholder-gray-400 resize-none leading-relaxed"
                  />
                </div>
              </div>
            ) : (
              /* Preview Mode */
              <div className="bg-white rounded-2xl p-8 shadow-sm border border-gray-100">
                <h1 className="text-3xl font-bold text-gray-900 mb-4">{formData.title || 'Untitled Post'}</h1>
                <div className="prose prose-lg max-w-none">
                  {formData.content.split('\n').map((paragraph, index) => (
                    <p key={index} className="mb-4 text-gray-700 leading-relaxed">
                      {paragraph}
                    </p>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Sidebar */}
        <div className="w-80 bg-white border-l border-gray-200 p-6 space-y-6">
          {/* Publishing Options */}
          <div>
            <h3 className="text-sm font-semibold text-gray-900 mb-3">Publishing</h3>
            <div className="space-y-3">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
                <select
                  value={formData.status}
                  onChange={(e) => handleInputChange('status', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                >
                  <option value="draft">Draft</option>
                  <option value="published">Published</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
                <select
                  value={formData.category}
                  onChange={(e) => handleInputChange('category', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                >
                  <option value="">Select Category</option>
                  {categories.map((category) => (
                    <option key={category.id} value={category.name}>
                      {category.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* Tags */}
          <div>
            <h3 className="text-sm font-semibold text-gray-900 mb-3">Tags</h3>
            <div className="space-y-3">
              <div className="flex space-x-2">
                <input
                  type="text"
                  placeholder="Add tag..."
                  value={tagInput}
                  onChange={(e) => setTagInput(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addTag())}
                  className="flex-1 px-3 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent text-sm"
                />
                <button
                  onClick={addTag}
                  className="px-4 py-2 bg-indigo-600 text-white text-sm font-medium rounded-lg hover:bg-indigo-700 transition-colors duration-200"
                >
                  Add
                </button>
              </div>
              <div className="flex flex-wrap gap-2">
                {formData.tags.map((tag, index) => (
                  <span
                    key={index}
                    className="inline-flex items-center px-3 py-1 rounded-full text-sm bg-indigo-100 text-indigo-800"
                  >
                    {tag}
                    <button
                      onClick={() => removeTag(tag)}
                      className="ml-2 text-indigo-600 hover:text-indigo-800"
                    >
                      ×
                    </button>
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Excerpt */}
          <div>
            <h3 className="text-sm font-semibold text-gray-900 mb-3">Excerpt</h3>
            <textarea
              placeholder="Brief description of your post..."
              value={formData.excerpt}
              onChange={(e) => handleInputChange('excerpt', e.target.value)}
              rows={3}
              className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent text-sm resize-none"
            />
          </div>

          {/* SEO Settings */}
          <div>
            <button
              onClick={() => setShowSEO(!showSEO)}
              className="flex items-center justify-between w-full text-sm font-semibold text-gray-900 mb-3"
            >
              <span>SEO Settings</span>
              <Settings className="w-4 h-4" />
            </button>
            {showSEO && (
              <div className="space-y-3">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">SEO Title</label>
                  <input
                    type="text"
                    placeholder="SEO optimized title..."
                    value={formData.seoTitle}
                    onChange={(e) => handleInputChange('seoTitle', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent text-sm"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Meta Description</label>
                  <textarea
                    placeholder="SEO meta description..."
                    value={formData.seoDescription}
                    onChange={(e) => handleInputChange('seoDescription', e.target.value)}
                    rows={2}
                    className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent text-sm resize-none"
                  />
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};