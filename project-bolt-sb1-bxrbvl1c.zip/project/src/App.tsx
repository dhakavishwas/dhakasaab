import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { BlogProvider } from './context/BlogContext';
import { Layout } from './components/Layout';
import { Dashboard } from './components/Dashboard';
import { PostsList } from './components/PostsList';
import { PostEditor } from './components/PostEditor';
import { PostView } from './components/PostView';

function App() {
  return (
    <BlogProvider>
      <Router>
        <div className="min-h-screen bg-gray-50">
          <Routes>
            <Route path="/" element={<Layout />}>
              <Route index element={<Dashboard />} />
              <Route path="posts" element={<PostsList />} />
              <Route path="editor" element={<PostEditor />} />
              <Route path="editor/:id" element={<PostEditor />} />
              <Route path="categories" element={<Dashboard />} />
              <Route path="analytics" element={<Dashboard />} />
              <Route path="settings" element={<Dashboard />} />
            </Route>
            <Route path="post/:slug" element={<PostView />} />
          </Routes>
        </div>
      </Router>
    </BlogProvider>
  );
}

export default App;