export interface BlogPost {
  id: string;
  title: string;
  slug: string;
  content: string;
  excerpt: string;
  author: string;
  category: string;
  tags: string[];
  status: 'draft' | 'published';
  createdAt: Date;
  updatedAt: Date;
  readingTime: number;
  featuredImage?: string;
  seoTitle?: string;
  seoDescription?: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  color: string;
  postCount: number;
}

export interface BlogContextType {
  posts: BlogPost[];
  categories: Category[];
  currentPost: BlogPost | null;
  searchTerm: string;
  selectedCategory: string;
  createPost: (post: Omit<BlogPost, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updatePost: (id: string, post: Partial<BlogPost>) => void;
  deletePost: (id: string) => void;
  setCurrentPost: (post: BlogPost | null) => void;
  setSearchTerm: (term: string) => void;
  setSelectedCategory: (category: string) => void;
}