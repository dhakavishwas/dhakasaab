import React, { createContext, useContext, useState, useCallback } from 'react';
import { BlogPost, Category, BlogContextType } from '../types/blog';

const BlogContext = createContext<BlogContextType | undefined>(undefined);

const generateSlug = (title: string): string => {
  return title
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');
};

const calculateReadingTime = (content: string): number => {
  const wordsPerMinute = 200;
  const words = content.trim().split(/\s+/).length;
  return Math.ceil(words / wordsPerMinute);
};

const defaultCategories: Category[] = [
  { id: '1', name: 'Technology', slug: 'technology', color: '#3B82F6', postCount: 0 },
  { id: '2', name: 'Design', slug: 'design', color: '#8B5CF6', postCount: 0 },
  { id: '3', name: 'Business', slug: 'business', color: '#10B981', postCount: 0 },
  { id: '4', name: 'Lifestyle', slug: 'lifestyle', color: '#F59E0B', postCount: 0 },
  { id: '5', name: 'Travel', slug: 'travel', color: '#EF4444', postCount: 0 },
];

const samplePosts: BlogPost[] = [
  {
    id: '1',
    title: 'Getting Started with Modern Web Development',
    slug: 'getting-started-modern-web-development',
    content: `# Getting Started with Modern Web Development

Web development has evolved significantly over the past few years. Modern frameworks and tools have made it easier than ever to build beautiful, responsive applications.

## Key Technologies

- **React**: A powerful library for building user interfaces
- **TypeScript**: Adds type safety to JavaScript
- **Tailwind CSS**: Utility-first CSS framework
- **Vite**: Fast build tool and development server

## Best Practices

1. Component-based architecture
2. Responsive design principles
3. Performance optimization
4. Accessibility considerations

Modern web development is about creating experiences that work seamlessly across all devices and platforms.`,
    excerpt: 'Discover the essential tools and practices for modern web development, from React to TypeScript.',
    author: 'Alex Johnson',
    category: 'Technology',
    tags: ['Web Development', 'React', 'TypeScript'],
    status: 'published',
    createdAt: new Date('2024-01-15'),
    updatedAt: new Date('2024-01-15'),
    readingTime: 3,
  },
  {
    id: '2',
    title: 'The Art of Minimalist Design',
    slug: 'art-of-minimalist-design',
    content: `# The Art of Minimalist Design

Minimalism in design is about removing the unnecessary and focusing on what truly matters. It's not about having less for the sake of less, but about having just enough.

## Core Principles

- **Simplicity**: Remove clutter and focus on essential elements
- **White Space**: Use negative space effectively
- **Typography**: Choose fonts that enhance readability
- **Color**: Use a limited palette for maximum impact

## Benefits

Minimalist design improves user experience by reducing cognitive load and creating clarity.`,
    excerpt: 'Explore the principles of minimalist design and how it can improve user experience.',
    author: 'Sarah Chen',
    category: 'Design',
    tags: ['Design', 'Minimalism', 'UX'],
    status: 'published',
    createdAt: new Date('2024-01-10'),
    updatedAt: new Date('2024-01-10'),
    readingTime: 2,
  },
];

export const BlogProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [posts, setPosts] = useState<BlogPost[]>(samplePosts);
  const [categories] = useState<Category[]>(defaultCategories);
  const [currentPost, setCurrentPost] = useState<BlogPost | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');

  const createPost = useCallback((postData: Omit<BlogPost, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newPost: BlogPost = {
      ...postData,
      id: Date.now().toString(),
      slug: generateSlug(postData.title),
      readingTime: calculateReadingTime(postData.content),
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    setPosts(prev => [newPost, ...prev]);
  }, []);

  const updatePost = useCallback((id: string, updates: Partial<BlogPost>) => {
    setPosts(prev => prev.map(post => 
      post.id === id 
        ? { 
            ...post, 
            ...updates, 
            slug: updates.title ? generateSlug(updates.title) : post.slug,
            readingTime: updates.content ? calculateReadingTime(updates.content) : post.readingTime,
            updatedAt: new Date() 
          }
        : post
    ));
  }, []);

  const deletePost = useCallback((id: string) => {
    setPosts(prev => prev.filter(post => post.id !== id));
  }, []);

  const value: BlogContextType = {
    posts,
    categories,
    currentPost,
    searchTerm,
    selectedCategory,
    createPost,
    updatePost,
    deletePost,
    setCurrentPost,
    setSearchTerm,
    setSelectedCategory,
  };

  return (
    <BlogContext.Provider value={value}>
      {children}
    </BlogContext.Provider>
  );
};

export const useBlog = (): BlogContextType => {
  const context = useContext(BlogContext);
  if (!context) {
    throw new Error('useBlog must be used within a BlogProvider');
  }
  return context;
};